# BINZ Device Monitor
Aplikasi Android untuk memeriksa baterai, penyimpanan, info perangkat, dan membuka pengaturan privasi pada HP sendiri. Tidak membaca chat/WhatsApp/SMS/OTP/notifikasi, tidak mengirim data, dan tidak berjalan diam-diam.

## Build APK dari HP melalui GitHub Actions
1. Buat repository GitHub baru dan upload seluruh isi folder proyek ini.
2. Buka Actions dan jalankan workflow `Build Android APK`.
3. Unduh artifact `binz-device-monitor-debug-apk` setelah workflow berhasil.
4. Ekstrak ZIP artifact dan instal APK pada HP sendiri.

Butuh JDK 17 dan Gradle untuk build lokal. Proyek sumber ini belum diuji pada perangkat fisik.
