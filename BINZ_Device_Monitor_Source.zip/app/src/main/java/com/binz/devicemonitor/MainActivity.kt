package com.binz.devicemonitor

import android.app.Activity
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DecimalFormat

class MainActivity : Activity() {
    private val bg = Color.rgb(13,16,26)
    private val panel = Color.rgb(26,31,47)
    private val accent = Color.rgb(91,150,255)
    private val muted = Color.rgb(175,185,205)
    private val df = DecimalFormat("#,##0.0")

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,30,22,28) }
        scroll.addView(page)
        page.addView(label("BINZ DEVICE MONITOR",24,Color.WHITE,true))
        page.addView(label("Pemeriksaan dasar perangkat • lokal di HP ini",14,muted,false).also { it.setPadding(0,8,0,20) })

        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE,-1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS,-1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        card(page,"BATERAI", if (pct >= 0) "$pct% • ${if (charging) "Mengisi / penuh" else "Tidak mengisi"}" else "Data tidak tersedia")

        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        card(page,"PENYIMPANAN INTERNAL","Terpakai: ${gb(total-free)} GB\nTersedia: ${gb(free)} GB\nTotal: ${gb(total)} GB")
        card(page,"PERANGKAT","Merek: ${Build.MANUFACTURER}\nModel: ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE}\nSDK: ${Build.VERSION.SDK_INT}")
        page.addView(label("PENGATURAN PRIVASI",16,Color.WHITE,true).also { it.setPadding(0,14,0,8) })
        button(page,"Buka izin aplikasi") {
            openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))
        }
        button(page,"Buka pengaturan privasi") { openSettings(Settings.ACTION_PRIVACY_SETTINGS,null) }
        button(page,"Perbarui informasi") { render() }
        page.addView(label("Privasi: aplikasi ini tidak mengirim data ke server dan tidak membaca pesan, WhatsApp, SMS, OTP, atau notifikasi. Data hanya ditampilkan di perangkat ini.",12,muted,false).also { it.setPadding(0,18,0,0) })
        setContentView(scroll)
    }

    private fun card(parent: LinearLayout, title: String, value: String) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,15,16,15); setBackgroundColor(panel) }
        box.addView(label(title,15,accent,true))
        box.addView(label(value,16,Color.WHITE,false).also { it.setPadding(0,8,0,0) })
        parent.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin=12 })
    }
    private fun button(parent: LinearLayout, title: String, action: () -> Unit) {
        val b = Button(this).apply { text=title; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(47,92,170)); setOnClickListener { action() } }
        parent.addView(b,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin=8 })
    }
    private fun openSettings(action: String, uri: android.net.Uri?) {
        try { val i=Intent(action); if(uri!=null) i.data=uri; startActivity(i) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    private fun label(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD)
    }
    private fun gb(bytes:Long)=df.format(bytes/(1024.0*1024.0*1024.0))
}
